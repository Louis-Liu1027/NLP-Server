from django.apps import AppConfig


class KgqaConfig(AppConfig):
    name = 'kgqa'
