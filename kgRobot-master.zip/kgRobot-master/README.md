# kgRobot
## 基于知识图谱的智能问答机器人
## QQ技术交流群：
- 344673972
- 点击链接加入群聊【智能对话机器人交流群】：https://jq.qq.com/?_wv=1027&k=5cBz1Xq

### 课程内容：
- 1.智能问答机器人完整案例演示
- 2.智能问答机器人开发环境部署
- 3.智能问答机器人框架关键技术
- 4.智能问答机器人源码完全剖析

### 线上配套视频课程地址：
[http://study.163.com/course/courseMain.htm?courseId=1005049028&utm_campaign=commission&utm_source=cp-1016839500&utm_medium=share](http://study.163.com/course/courseMain.htm?courseId=1005049028&utm_campaign=commission&utm_source=cp-1016839500&utm_medium=share "智能对话机器人实战开发案例完全剖析")
