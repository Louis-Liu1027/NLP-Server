let express = require('express')
let router = express.Router()
let login = require('./API/login')

router.get('/login', login.login)
router.post('/register', login.register)
router.get('/user', login.get)
router.get('/test', login.test)

module.exports = router
